
-- Calculate salary
CREATE FUNCTION GetSalary(
	@ProfessionSalary INT = 0,
	@ChildrenCount INT = 0
)
RETURNS INT
AS 
BEGIN
    DECLARE @Result INT
    
    SET @Result = @ProfessionSalary + (@ProfessionSalary / 10 * @ChildrenCount)
    
    RETURN @Result
END 
go

