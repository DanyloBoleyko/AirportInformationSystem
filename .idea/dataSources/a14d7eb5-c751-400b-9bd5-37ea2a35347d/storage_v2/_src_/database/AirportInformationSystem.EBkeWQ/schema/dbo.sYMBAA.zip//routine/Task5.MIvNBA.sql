

---======---
-- Task 5 --
---======---

-- Одержати перелік і загальну кількість літаків, що пройшли техогляд за певний період часу; 
-- ремонтованих задану кількість разів; за кількістю здійснених рейсів до ремонту; за віком літака
CREATE PROC Task5
	@InspectionDateRangeStart DATETIME = NULL,
	@InspectionDateRangeEnd DATETIME = NULL,
	@RepairCount INT = NULL
AS
--
SELECT 
	a.Name AS Name,
	t.Name AS Type,
	(DATEDIFF(YEAR, a.BuiltDate, GETDATE())) AS Age,
	i.InspectionDatetime AS InspectionDatetime,
	i.Result AS InspectionResult,
    COUNT(f.FlightID) AS FlightCount
FROM 
	Aircraft a
	INNER JOIN AircraftType t ON t.AircraftTypeID = a.AircraftTypeID
	INNER JOIN Inspection i ON i.AircraftID = a.AircraftID
    LEFT JOIN Flight f ON f.AircraftID = a.AircraftID
WHERE
	a.RepairCount = ISNULL(@RepairCount, a.RepairCount)
	AND i.InspectionDatetime >= ISNULL(@InspectionDateRangeStart, i.InspectionDatetime)
	AND i.InspectionDatetime <= ISNULL(@InspectionDateRangeEnd, i.InspectionDatetime)
GROUP BY
    a.Name,
    t.Name,
    a.BuiltDate,
    i.InspectionDatetime,
    i.Result
ORDER BY
    COUNT(f.FlightID) DESC;
SELECT @@ROWCOUNT AS 'Count';
--
go

