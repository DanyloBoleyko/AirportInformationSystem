

---=======---
-- Task 13 --
---=======---

-- Отримати загальну кількість зданих квитків на деякий рейс; за ціною квитка; за віком
CREATE PROC Task13
	@FlightID INT = NULL
AS
--
SELECT 
	*
FROM 
	Flight f
	INNER JOIN Schedule s ON s.ScheduleID = f.ScheduleID
	INNER JOIN Ticket tk ON tk.FlightID = f.FlightID
	INNER JOIN Passenger ps ON ps.TicketID = tk.TicketID
WHERE
	tk.Status = N'Сдано'
ORDER BY
	s.TicketPrice,
	ps.Age
SELECT @@ROWCOUNT AS 'Count';
--
go

