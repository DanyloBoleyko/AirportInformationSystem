

---======---
-- Task 7 --
---======---

-- Одержати перелік і загальну кількість скасованих рейсів повністю; у зазначеному напрямку; 
-- за вказаним маршрутом; за кількістю вільних місць; за відсотковим співвідношенням вільних і зайнятих місць
CREATE PROC Task7
	@FromAirport INT = NULL,
	@ToAirport INT = NULL
AS
--
SELECT 
	f.FlightID,
	t.TicketCount,
	atp.PlaceCount,
	atp.PlaceCount - t.TicketCount as FreePlaces, 
	((atp.PlaceCount - t.TicketCount) / t.TicketCount) * 100 as PercentageRatio
FROM 
	Flight f
	INNER JOIN Schedule s ON s.ScheduleID = f.ScheduleID
	INNER JOIN ScheduleRoute sr ON sr.ScheduleID = s.ScheduleID
	INNER JOIN Aircraft a ON a.AircraftID = f.AircraftID
	INNER JOIN AircraftType atp ON atp.AircraftTypeID = a.AircraftTypeID
	LEFT JOIN (
        SELECT FlightID, COUNT(TicketID) AS TicketCount
        FROM Ticket
        GROUP BY FlightID
    ) t ON t.FlightID = f.FlightID
WHERE
	f.Status = N'Скасовано'
	AND sr.FromAirportID = ISNULL(@FromAirport, sr.FromAirportID)
	AND sr.ToAirportID = ISNULL(@ToAirport, sr.ToAirportID)
ORDER BY
	FreePlaces,
	PercentageRatio
SELECT @@ROWCOUNT AS 'Count';
--
go

