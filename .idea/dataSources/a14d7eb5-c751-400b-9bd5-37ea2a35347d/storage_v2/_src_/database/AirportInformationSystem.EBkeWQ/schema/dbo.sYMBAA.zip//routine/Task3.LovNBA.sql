

---======---
-- Task 3 --
---======---

-- Одержати перелік і загальну кількість пілотів, які пройшли медогляд або не пройшли його в 
-- зазначений рік, за статевою ознакою, за віком, за розміром заробітної платні
CREATE PROC Task3
	@Passed BIT = 1,
	@Year INT = NULL
AS
--
SELECT 
	e.Name AS Name,
	(DATEDIFF(YEAR, e.BirthDate, GETDATE())) AS Age,
	e.Gender AS Gender,
	e.Children AS Children,
	dbo.GetSalary(p.Salary, e.Children) AS Salary
FROM 
	Employee e
	JOIN Profession p ON e.ProfessionID = p.ProfessionID
WHERE 
	p.Name = N'Пілот'
	AND (
		(NOT EXISTS (
			SELECT * FROM Diagnostic dg
			WHERE dg.EmployeeID = e.EmployeeID
			AND YEAR(dg.DiagnosticDate) = ISNULL(@Year, YEAR(dg.DiagnosticDate))
		) AND @Passed = 0) 
		OR (EXISTS (
			SELECT * FROM Diagnostic dg
			WHERE dg.EmployeeID = e.EmployeeID
			AND YEAR(dg.DiagnosticDate) = ISNULL(@Year, YEAR(dg.DiagnosticDate))
		) AND @Passed = 1)
	)
ORDER BY 
	Gender, 
	Age DESC,
	p.Salary DESC
SELECT @@ROWCOUNT AS 'Count';
--
go

