


---=========---
-- FUNCTIONS --
---=========---

-- Get total employee count
CREATE FUNCTION GetTotalEmployeeCount(
	@DepartmentID INT = NULL, 
	@DepartmentName VARCHAR(50) = NULL,
	@BrigadeID INT = NULL,
	@BrigadeName VARCHAR(50) = NULL
)
RETURNS INT
AS 
BEGIN
    DECLARE @Result INT
    
    SELECT @Result = COUNT(*) 
    FROM 
        Employee e 
        LEFT JOIN EmployeeBrigade eb ON eb.EmployeeID = e.EmployeeID
        LEFT JOIN Brigade b ON b.BrigadeID = eb.BrigadeID
        LEFT JOIN Department bd ON bd.DepartmentID = b.DepartmentID
    WHERE
        ISNULL(@DepartmentID, bd.DepartmentID) = bd.DepartmentID
        AND ISNULL(@DepartmentName, bd.Name) = bd.Name
		AND ISNULL(@BrigadeID, b.BrigadeID) = b.BrigadeID
        AND ISNULL(@BrigadeName, b.Name) = b.Name
    
    RETURN @Result
END 
go

