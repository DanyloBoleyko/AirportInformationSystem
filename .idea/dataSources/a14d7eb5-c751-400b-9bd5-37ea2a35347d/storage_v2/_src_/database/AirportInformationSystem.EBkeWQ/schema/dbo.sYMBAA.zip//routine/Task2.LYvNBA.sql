

---======---
-- Task 2 --
---======---

-- Одержати перелік і загальну кількість робітників в бригаді, по усіх відділах, у зазначеному відділі, 
-- які обслуговують конкретний рейс, за віком, за сумарною (середньою) зарплатнею в бригаді
CREATE PROC Task2
	@DepartmentID INT = NULL,
	@DepartmentName VARCHAR(50) = NULL,
	@FlightID INT = NULL
AS
--
SELECT 
	e.Name AS Name,
	(DATEDIFF(YEAR, e.StartWorkingDate, GETDATE())) AS WorkExperience,
	e.Gender AS Gender,
	e.Children AS Children,
	CASE WHEN e.Children > 0 THEN 'True' ELSE 'False' END AS HasChildren,
	(DATEDIFF(YEAR, e.BirthDate, GETDATE())) AS Age,
	dbo.GetSalary(
		p.Salary, 
		e.Children
	) AS Salary,
	p.Name AS Profession,
	bd.Name AS EmployeeOfDepartment,
	CASE WHEN @FlightID IS NULL THEN NULL ELSE f.FlightID END AS FlightID,
	AVG(dbo.GetSalary(p.Salary, e.Children)) OVER (PARTITION BY b.BrigadeID) AS AvgSalaryInBrigade
FROM 
	Employee e
	JOIN Profession p ON e.ProfessionID = p.ProfessionID
	LEFT JOIN EmployeeBrigade eb ON eb.EmployeeID = e.EmployeeID
	LEFT JOIN Brigade b ON b.BrigadeID = eb.BrigadeID
	LEFT JOIN Department bd ON bd.DepartmentID = b.DepartmentID
	OUTER APPLY (
		SELECT TOP 1 FlightID 
		FROM Flight f 
		JOIN Aircraft a ON f.AircraftID = a.AircraftID
		JOIN AircraftBrigade ab ON ab.AircraftID = a.AircraftID
		WHERE ab.BrigadeID = b.BrigadeID
			AND (@FlightID IS NULL OR f.FlightID = @FlightID)
	) AS f
WHERE 
	ISNULL(@DepartmentID, bd.DepartmentID) = bd.DepartmentID
	AND ISNULL(@DepartmentName, bd.Name) = bd.Name
	AND (@FlightID IS NULL OR @FlightID = f.FlightID)
ORDER BY 
	WorkExperience, 
	Gender, 
	Age DESC,
	HasChildren DESC,
	Children DESC,
	p.Salary DESC
SELECT @@ROWCOUNT AS 'Count';
--
go

