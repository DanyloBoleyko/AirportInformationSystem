

---======---
-- Task 4 --
---======---

-- Одержати перелік і загальну кількість літаків приписаних до аеропорту, 
-- що знаходяться в ньому у вказаний час, за часом прильоту до аеропорту, 
-- за кількістю здійснених рейсів. 
CREATE PROC Task4
	@AirportID INT = NULL,
	@DatetimeRangeStart DATETIME = NULL,
	@DatetimeRangeEnd DATETIME = NULL
AS
SELECT 
	a.Name,
	MAX(f.ArrivalDatetime) AS ArrivalDatetime,
	MAX(f.Status) AS Status,
	fr.DepartureTime
FROM 
	Aircraft a
	INNER JOIN AirportAircraft apa ON apa.AircraftID = a.AircraftID
	INNER JOIN Airport ap ON ap.AirportID = apa.AirportID
	INNER JOIN Flight f ON f.AircraftID = a.AircraftID
	INNER JOIN FlightRoute fr ON fr.FlightID = f.FlightID
WHERE
	ap.AirportID = ISNULL(@AirportID, ap.AirportID)
	AND EXISTS (
		SELECT * FROM 
			Flight F
			INNER JOIN FlightRoute FR ON FR.FlightID = F.FlightID
		WHERE F.AircraftID = a.AircraftID
			AND (
				FR.DepartureTime > @DatetimeRangeStart
				AND FR.DepartureTime < @DatetimeRangeEnd
			) OR (
				FR.ArrivalTime <= @DatetimeRangeStart
				AND FR.ArrivalTime >= @DatetimeRangeEnd
			)
	)
GROUP BY
	a.Name, fr.DepartureTime
SELECT @@ROWCOUNT AS 'Count';
--
go

