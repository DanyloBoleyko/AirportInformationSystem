

---======---
-- Task 6 --
---======---

-- Одержати перелік і загальну кількість рейсів за вказаним маршрутом, за тривалістю перельоту, 
-- за ціною квитка і за всіма цими критеріями одночасно
CREATE PROC Task6
	@FromAirport INT = NULL,
	@ToAirport INT = NULL,
	@FlightTime TIME = NULL,
	@TicketPrice DECIMAL(10,2) = NULL
AS
--
SELECT 
	f.ArrivalDatetime, 
	f.DepartureDatetime,
	f.AircraftID,
	f.Status,
	s.EstimatedFlightTime,
	s.TicketPrice,
	s.TicketPriceDiscounted,
	sr.FromAirportID AS FromAirportID,
	sr.ToAirportID AS ToAirportID
FROM 
	Flight f
	INNER JOIN Schedule s ON s.ScheduleID = f.ScheduleID
	INNER JOIN ScheduleRoute sr ON sr.ScheduleID = s.ScheduleID
WHERE
	s.EstimatedFlightTime = ISNULL(@FlightTime, s.EstimatedFlightTime)
	AND sr.FromAirportID = ISNULL(@FromAirport, sr.FromAirportID)
	AND sr.ToAirportID = ISNULL(@ToAirport, sr.ToAirportID)
	AND s.TicketPriceDiscounted = ISNULL(@TicketPrice, s.TicketPriceDiscounted)
ORDER BY
	s.EstimatedFlightTime,
	s.TicketPriceDiscounted
SELECT @@ROWCOUNT AS 'Count';
--
go

