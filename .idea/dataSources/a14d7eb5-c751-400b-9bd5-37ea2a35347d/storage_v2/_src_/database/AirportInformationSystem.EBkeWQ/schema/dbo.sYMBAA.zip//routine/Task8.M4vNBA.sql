

---======---
-- Task 8 --
---======---

-- Одержати перелік і загальну кількість затриманих рейсів повністю, вказаної причиною; за вказаним маршрутом. 
CREATE PROC Task8
	@LateReason VARCHAR(150) = NULL
AS
--
SELECT 
	*,
	CAST((s.EstimatedFlightTime) as time(0)) as EstimatedFlightTime,
	CAST((f.ArrivalDatetime - f.DepartureDatetime) as time(0)) as FlightTime
FROM 
	Flight f
	INNER JOIN Schedule s ON s.ScheduleID = f.ScheduleID
WHERE
	DATEPART(HOUR, s.EstimatedFlightTime) < DATEDIFF(HOUR, f.DepartureDatetime, f.ArrivalDatetime)
	OR (
		DATEPART(HOUR, s.EstimatedFlightTime) = DATEDIFF(HOUR, f.DepartureDatetime, f.ArrivalDatetime)
		AND DATEPART(MINUTE, s.EstimatedFlightTime) < DATEDIFF(MINUTE, f.DepartureDatetime, f.ArrivalDatetime)
	)
	AND f.ArrivalLateReason = @LateReason
SELECT @@ROWCOUNT AS 'Count';
--
go

