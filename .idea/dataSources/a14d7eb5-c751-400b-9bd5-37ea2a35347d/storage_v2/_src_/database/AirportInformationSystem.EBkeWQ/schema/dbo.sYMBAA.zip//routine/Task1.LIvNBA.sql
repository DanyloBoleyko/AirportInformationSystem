

---======---
-- Task 1 --
---======---

-- Одержати список і загальну кількість всіх робітників аеропорту, керівників відділів, робітників зазначеного відділу, 
-- за стажем роботи в аеропорту, статевою ознакою, віком, ознакою наявності та кількості дітей, за розміром заробітної платні. 
CREATE PROC Task1 
	@DepartmentID INT = NULL,
	@DepartmentName VARCHAR(50) = NULL
AS
--
SELECT 
	e.Name AS Name,
	(DATEDIFF(YEAR, e.StartWorkingDate, GETDATE())) AS WorkExperience,
	e.Gender AS Gender,
	e.Children AS Children,
	CASE WHEN e.Children > 0 THEN 'True' ELSE 'False' END AS HasChildren,
	(DATEDIFF(YEAR, e.BirthDate, GETDATE())) AS Age,
	p.Salary,
	p.Name AS Profession,
	d.Name AS ManagerOfDepartment,
	bd.Name AS EmployeeOfDepartment
FROM 
	Employee e
	JOIN Profession p ON e.ProfessionID = p.ProfessionID
	LEFT JOIN DepartmentManager dm ON e.EmployeeID = dm.EmployeeID
	LEFT JOIN Department d ON dm.DepartmentID = d.DepartmentID
	LEFT JOIN EmployeeBrigade eb ON eb.EmployeeID = e.EmployeeID
	LEFT JOIN Brigade b ON b.BrigadeID = eb.BrigadeID
	LEFT JOIN Department bd ON bd.DepartmentID = b.DepartmentID
WHERE 
	ISNULL(@DepartmentID, bd.DepartmentID) = bd.DepartmentID
	AND ISNULL(@DepartmentName, bd.Name) = bd.Name
ORDER BY 
	WorkExperience, 
	Gender, 
	Age DESC,
	HasChildren DESC,
	Children DESC,
	p.Salary DESC
SELECT @@ROWCOUNT AS 'Count';
--
go

