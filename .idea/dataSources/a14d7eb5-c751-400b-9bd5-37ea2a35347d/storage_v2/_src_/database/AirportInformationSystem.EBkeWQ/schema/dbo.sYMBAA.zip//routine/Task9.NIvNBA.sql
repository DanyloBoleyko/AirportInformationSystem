

---======---
-- Task 9 --
---======---

-- Одержати перелік і загальну кількість рейсів, за якими літають літаки заданого типу 
-- і середню кількість проданих квитків на певні маршрути; за тривалістю перельоту; за ціною квитка
CREATE PROC Task9
	@AircraftType INT = NULL,
	@FromAirport INT = NULL,
	@ToAirport INT = NULL
AS
--
SELECT 
	*
FROM 
	Flight f
	INNER JOIN Aircraft a ON a.AircraftID = f.AircraftID
	INNER JOIN AircraftType atp ON atp.AircraftTypeID = a.AircraftTypeID
	INNER JOIN Schedule s ON s.ScheduleID = f.ScheduleID
	INNER JOIN ScheduleRoute sr ON sr.ScheduleID = s.ScheduleID
WHERE
	atp.AircraftTypeID = ISNULL(@AircraftType, atp.AircraftTypeID)
	AND sr.FromAirportID = ISNULL(@FromAirport, sr.FromAirportID)
	AND sr.ToAirportID = ISNULL(@ToAirport, sr.ToAirportID)
ORDER BY
	s.EstimatedFlightTime,
	s.TicketPrice
SELECT @@ROWCOUNT AS 'Count';
--
go

