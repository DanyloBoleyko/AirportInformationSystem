

---=======---
-- Task 12 --
---=======---

-- Одержати перелік і загальну кількість вільних і заброньованих місць на зазначеному рейсі   
-- на певний день; за ціною, за часом вильоту
CREATE PROC Task12
	@FlightID INT = NULL
AS
--
SELECT 
	f.*,
	t.TicketCount as BoughtCount,
	atp.PlaceCount - t.TicketCount as FreeCount
FROM 
	Flight f
	INNER JOIN Schedule s ON s.ScheduleID = f.ScheduleID
	INNER JOIN ScheduleRoute sr ON sr.ScheduleID = s.ScheduleID
	INNER JOIN Ticket tk ON tk.FlightID = f.FlightID
	INNER JOIN Aircraft a ON a.AircraftID = f.AircraftID
	INNER JOIN AircraftType atp ON atp.AircraftTypeID = a.AircraftTypeID
	LEFT JOIN (
        SELECT FlightID, COUNT(TicketID) AS TicketCount
        FROM Ticket
		WHERE FlightID = ISNULL(@FlightID, FlightID)
        GROUP BY FlightID
    ) t ON t.FlightID = f.FlightID
WHERE
	f.FlightID = ISNULL(@FlightID, f.FlightID)
ORDER BY
	s.TicketPrice,
	f.DepartureDatetime
SELECT @@ROWCOUNT AS 'Count';
--
go

