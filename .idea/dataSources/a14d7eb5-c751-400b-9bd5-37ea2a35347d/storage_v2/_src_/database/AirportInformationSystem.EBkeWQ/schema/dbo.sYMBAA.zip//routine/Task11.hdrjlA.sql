

---=======---
-- Task 11 --
---=======---

-- Одержати перелік і загальну кількість пасажирів на даному рейсі, які вилетіли в зазначений день; 
-- за ознакою здачі речей у багажне відділення; за статевою ознакою; за віком
CREATE PROC Task11
	@FlightID INT = NULL,
	@HasBaggage BIT = NULL,
	@Gender CHAR(1) = NULL
AS
--
SELECT 
	f.*
FROM 
	Flight f
	INNER JOIN Schedule s ON s.ScheduleID = f.ScheduleID
	INNER JOIN ScheduleRoute sr ON sr.ScheduleID = s.ScheduleID
	INNER JOIN Ticket tk ON tk.FlightID = f.FlightID
	INNER JOIN Passenger ps ON ps.TicketID = tk.TicketID
	INNER JOIN Luggage lg ON lg.PassengerID = ps.PassengerID
WHERE
	f.FlightID = ISNULL(@FlightID, f.FlightID)
	AND ps.Gender = ISNULL(@Gender, ps.Gender)
	AND (@HasBaggage IS NULL OR
        (@HasBaggage = 1 AND EXISTS (SELECT 1 FROM Luggage WHERE PassengerID = ps.PassengerID)) OR
        (@HasBaggage = 0 AND NOT EXISTS (SELECT 1 FROM Luggage WHERE PassengerID = ps.PassengerID))
    )
SELECT @@ROWCOUNT AS 'Count';
--
go

